# Diamond Games

Three interactive mini games: mining, polishing and setting a diamond.
Static web edition v10. No account, backend or installation is required.

## Run

Open the published GitHub Pages URL, or serve this entire directory locally:

    python3 -m http.server 8000

Then open http://localhost:8000. Keep all folders beside index.html.
For the previous double-click offline edition, use the accepted v9 package.

## Loading

- index.html contains only the shared navigation and tools.
- Each game document loads on its first visit.
- Mining loads its five accepted WebP stages.
- Polishing requests only the four lossless images of the selected shape.
  Choosing another shape requests that shape; other shapes are not prefetched.
- Setting mounts one selected ring iframe. Its frame sequence loads progressively.
  Changing the ring removes the previous iframe. Other rings are not prefetched.
- Normal browser caching reuses files already visited.
- There is no service worker or background collection download.

## Controls

Mining: four strikes; reset and sound on/off in the external tools.
Polishing: three rounds, shape selection, demo and reset. The accepted 96% manual
completion threshold and tool size remain unchanged.
Setting: sixteen rings, drag to insert, rollback after an incomplete attempt,
then withdrawal, zoom and closing the mount. Final UI waits for completion.

## Artwork

Mining and polishing artwork stays in its accepted lossless WebP format.
Ring frames stay 750 x 680, 127 WebP images per product, at 30 fps.
Frames are copied without recompression; only page titles and robots metadata
are adjusted for this web edition.

Every HTML page requests noindex/nofollow/noarchive/nosnippet.
The repository and website are public; these directives are not access control.

Manrope and Lottie license files are included.
