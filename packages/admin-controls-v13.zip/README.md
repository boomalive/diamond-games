# Diamond Games

Three interactive mini games and a final 3D ring viewer.
Static web edition v13. No account, backend or installation is required.

## Run

Open the published GitHub Pages URL, or serve this entire directory locally:

    python3 -m http.server 8000

Then open http://localhost:8000. Keep all folders beside index.html.
For the previous double-click offline edition, use the accepted v9 package.

## Loading

- index.html contains only the shared navigation and tools.
- Each game document loads on its first visit.
- Mining loads its five accepted WebP stages.
- Polishing requests only the four lossless images of the selected shape.
  Choosing another shape requests that shape; other shapes are not prefetched.
- Setting mounts one selected ring iframe. Its frame sequence loads progressively.
  Changing the ring removes the previous iframe. Other rings are not prefetched.
- Final mounts one selected 3D viewer from ring-collection-v12-v3.
  Only its HTML and GLB load. Changing the ring destroys the previous iframe.
- Normal browser caching reuses files already visited.
- There is no service worker or background collection download.

## Controls

Mining: four strikes; reset and sound on/off in the external tools.
Polishing: three rounds, shape selection, demo and reset. The accepted 96% manual
completion threshold and tool size remain unchanged.
Setting: sixteen rings, drag to insert, rollback after an incomplete attempt,
then withdrawal, zoom and closing the mount. Final UI waits for completion.
Final: Figma screen 366:3415, sixteen finished rings and mouse/touch rotation.
The setting and final admin ring selectors are temporarily hidden pending approval;
their code is preserved, and the setting reset remains available.
The original tilted pose rotates about a screen-vertical axis through its centre.
Scrolling toward the form shrinks the same live viewer beneath the fixed header;
scrolling back restores its full size. The model and rotation phase are preserved.
After release the viewer waits two seconds before smoothly returning to its
original tilt and continuing its 360-degree path. Re-engaging cancels the pending
return; the next release starts a fresh two-second wait. Hidden tabs pause the
countdown. No play/pause controls. The setting completion
button opens the matching final ring. The form is a preview and sends no emails.
Downloading a 1500-pixel PNG of the current ring pose works locally in the browser.

## Artwork

Mining and polishing artwork stays in its accepted lossless WebP format.
Ring frames stay 750 x 680, 127 WebP images per product, at 30 fps.
Frames are copied without recompression; only page titles and robots metadata
are adjusted for this web edition.
The complete supplied 3D collection is in final-rings/. Its GLBs, materials,
studio settings, shaders and licenses are preserved. Viewer HTML loads the
matching original GLB file rather than an embedded Base64 duplicate.

Every HTML page requests noindex/nofollow/noarchive/nosnippet.
The repository and website are public; these directives are not access control.

Manrope and Lottie license files are included.
