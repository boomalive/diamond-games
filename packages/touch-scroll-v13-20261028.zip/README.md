# Diamond Games

Three interactive mini games and a final 3D ring viewer.
Static web edition v13. No account, backend or installation is required.

## Run

Open the published GitHub Pages URL, or serve this entire directory locally:

    python3 -m http.server 8000

Then open http://localhost:8000. Keep all folders beside index.html.
For the previous double-click offline edition, use the accepted v9 package.

## Loading

- index.html contains only the shared navigation and tools.
- Each game document loads on its first visit.
- Mining loads its five accepted WebP stages.
- Polishing requests only the four lossless images of the selected shape.
  Choosing another shape requests that shape; other shapes are not prefetched.
- Setting mounts one selected ring iframe. Its frame sequence loads progressively.
  Changing the ring removes the previous iframe. Other rings are not prefetched.
- Final mounts one selected 3D viewer from ring-collection-v12-v3.
  Only its HTML and GLB load. Changing the ring destroys the previous iframe.
- Normal browser caching reuses files already visited.
- There is no service worker or background collection download.

## Controls

Mining: four strikes; reset and sound on/off in the external tools.
Polishing: three rounds, shape selection, demo and reset. The accepted 96% manual
completion threshold and tool size remain unchanged.
Polishing and setting keep finger gestures inside the game, including nested
frames in mobile Safari. The host page stays still while those tabs are active;
the final tab retains its scrollable form.
Setting: sixteen rings, drag to insert, rollback after an incomplete attempt,
then withdrawal, zoom and closing the mount. Final UI waits for completion.
LR2882BR01 alone uses the centred frontal trial in ring-setting-frontal-v5/,
with parallel silver jaws, short curved tips extending past the contact point,
and separate tool reflections. The original
ring/stone studio and frames after tool withdrawal are preserved.
The setting admin selector compares the previous and new camera positions.
Both variants finish at the accepted original three-quarter pose after insertion.
The other fifteen products retain their accepted frames and camera positions.
Final: Figma screen 366:3415, sixteen finished rings and mouse/touch rotation.
The setting and final admin ring selectors are temporarily hidden pending approval;
their code is preserved, and the setting reset remains available.
The original tilted pose rotates about the ring's own Y axis, matching the
original collection catalogue. Each ring is framed to fit its complete turn
inside the preview, with room above the specifications.
Scrolling toward the form shrinks the same live viewer beneath the fixed header;
scrolling back restores its full size. The model and rotation phase are preserved.
After release the viewer waits two seconds before smoothly returning to its
original tilt and continuing its 360-degree path. Re-engaging cancels the pending
return; the next release starts a fresh two-second wait. Hidden tabs pause the
countdown. No play/pause controls. The setting completion
button opens the matching final ring. The form is a preview and sends no emails.
The presentation camera matches the four-cut LR2882 catalogue. Downloading a
1500-pixel PNG always uses its fixed three-quarter pose, independently of live
rotation, dragging or scrolling. The live viewer resumes in exactly the same state.

## Artwork

Mining and polishing artwork stays in its accepted lossless WebP format.
The second polishing image for each of the four shapes uses the user's latest
PNG attachments from the folder "доработка этапа огранки", supplied on
2026-10-28 and encoded losslessly at the supplied 2000 x 2000 size.
Only the selected shape loads; the other three image states remain unchanged.
Ring frames stay 750 x 680, 127 WebP images per product, at 30 fps.
Frames are copied without recompression. Embedded game pages receive neutral
titles, robots metadata and a scoped native-touch scrolling guard.
The complete supplied 3D collection is in final-rings/. Its GLBs, materials,
studio settings, shaders and licenses are preserved. Viewer HTML loads the
matching original GLB file rather than an embedded Base64 duplicate.

Every HTML page requests noindex/nofollow/noarchive/nosnippet.
The repository and website are public; these directives are not access control.

Manrope and Lottie license files are included.
